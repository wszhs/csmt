This list of files are:

 - attack.list: contains sha256 codes of 800 malware APKs for waging evasion attacks
 - benign_sha256.csv: contains sha256 codes of benign APKs used in the paper.
 - malicious_sha256.csv: contains sha256 codes of malicious APKs used in the paper.
 - drebin.tar.gz: the meta data obtained by pre-precessing process (Caution: The pre-processed data uses the feature extraction method that is outdate).

All APKs can be obtained by applying to official Androzoo website.